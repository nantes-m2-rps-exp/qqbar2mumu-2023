# Brian
## Code
- [x] JPsi MC separation
- [x] same function call for differential and main
- [x] finish NA60 with auto p0 swap
- [x] chi2 selection for syst
    * problem
- [ ] SNR for each pT
## Article
- [x] add CB2 reference in biblio
- [x] systematic analysis paragraph
- [x] figures captions
- [-] results (chi2, fig, table)
- [ ] add Charlig SNR in table
## TDR
- [x] modify stat eq
- [x] modify figures
- [x] captions
- [x] modify res
- [x] modify paragraphs models (reso)
- [x] translate systematic